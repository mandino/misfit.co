=== WooCommerce Stripe Gateway ===

A payment gateway for Stripe (https://stripe.com/). A Stripe account and a server with SSL support/a valid SSL certificate is required (for security reasons) for this gateway to function.

== Important Note ==

You *must* enable SSL from the settings panel to use this plugin in a live environment - this is for your customers safety and security.